package webapp;

public class UserValidator {
	public boolean isValid(String user, String password) {
		return user.equalsIgnoreCase("rany") && password.equals("1234");
	}
}
