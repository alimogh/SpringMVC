package com.johnbryce.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("name")
public class LoginController {

	@Autowired
	private UserValidator userValidator;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage() {
		// login
		// 1. login.jsp
		// 2. /WEB-INF/views/login.jsp
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String handleLoginRequest(@RequestParam String userName,
			@RequestParam String userPassword, ModelMap model) {

		if (userValidator.isValid(userName, userPassword)) {
			model.put("name", userName);
			model.put("password", userPassword);
			return "welcome";
		}

		model.put("errorMessage", "Invalid user name and/or password");

		return "login";
	}
}
