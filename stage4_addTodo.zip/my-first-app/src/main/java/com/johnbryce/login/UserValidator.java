package com.johnbryce.login;

import org.springframework.stereotype.Service;

@Service
public class UserValidator {
	public boolean isValid(String user, String password) {
		return user.equalsIgnoreCase("rany") && password.equals("1234");
	}
}
